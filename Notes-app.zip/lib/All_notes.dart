import 'package:flutter/material.dart';
import 'package:notes_app/edit.dart';

class Notes extends StatefulWidget {
  Notes({Key? key}) : super(key: key);

  @override
  State<Notes> createState() => _NotesState();
}

class _NotesState extends State<Notes> {
  List<bool> isFavorite = List.generate(3, (_) => false);
  int _selectedIndex = 1;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notes"),
        centerTitle: true,
        leading: IconButton(onPressed: () {}, icon: Icon(Icons.save)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Row(
                  children: [
                    Icon(Icons.search, color: Colors.grey),
                    SizedBox(width: 12),
                    Text(
                      "Search",
                      style: TextStyle(fontSize: 22, color: Colors.grey),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: isFavorite.length,
                itemBuilder: (context, index) => noteItem(index),
              ),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: EdgeInsets.only(bottom: 90),
        child: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return Edit();
            }));
          },
          backgroundColor: Color(0xffaba7a7),
          child: Icon(Icons.add, color: Color(0xff000000)),
          shape: CircleBorder(),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        notchMargin: 8,
        color: Colors.white,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 30, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(Icons.home,
                    color:
                        _selectedIndex == 0 ? Color(0xff321a70) : Colors.grey),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.note,
                    color:
                        _selectedIndex == 1 ? Color(0xff321a70) : Colors.grey),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.person,
                    color:
                        _selectedIndex == 2 ? Color(0xff321a70) : Colors.grey),
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget noteItem(int index) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          height: 70,
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Note Title",
                style: TextStyle(fontSize: 22, color: Colors.black),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    isFavorite[index] = !isFavorite[index];
                  });
                },
                icon: Icon(
                  isFavorite[index] ? Icons.favorite : Icons.favorite_border,
                  color: isFavorite[index] ? Colors.red : Colors.grey,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }
}
