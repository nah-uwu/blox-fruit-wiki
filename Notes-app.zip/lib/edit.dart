import 'package:flutter/material.dart';
import 'package:notes_app/All_notes.dart';

class Edit extends StatefulWidget {
  Edit({Key? key}) : super(key: key);

  @override
  State<Edit> createState() => _EditState();
}

class _EditState extends State<Edit> {
  TextEditingController newnote = TextEditingController();
  TextEditingController description = TextEditingController();
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.save)),
        ],
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Add"),
            SizedBox(width: 4),
            Text("Note"),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Title", style: TextStyle(fontSize: 30)),
              SizedBox(height: 14),
              TextFormField(
                controller: newnote,
                decoration: InputDecoration(
                  labelText: "Note Title",
                  labelStyle: TextStyle(color: Color(0xff321a70)),
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xff321a70)),
                  ),
                  prefixIcon: Icon(Icons.edit),
                  prefixIconColor: Color(0xff321a70),
                ),
              ),
              SizedBox(height: 40),
              Text("Description", style: TextStyle(fontSize: 30)),
              SizedBox(height: 14),
              Row(
                children: [
                  Icon(Icons.edit, color: Color(0xff321a70)),
                  SizedBox(width: 6),
                  Text(
                    "Note Description",
                    style: TextStyle(
                      color: Color(0xff321a70),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 6),
              TextFormField(
                controller: description,
                maxLines: 5,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xff321a70)),
                  ),
                  filled: true,
                  fillColor: Color(0xfff0f0f0),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: EdgeInsets.only(bottom: 90),
        child: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return Notes();
            }));
          },
          backgroundColor: Color(0xffaba7a7),
          child: Icon(Icons.check, color: Color(0xff000000)),
          shape: CircleBorder(),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        notchMargin: 8,
        color: Colors.white,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 30, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(Icons.home,
                    color:
                        _selectedIndex == 0 ? Color(0xff321a70) : Colors.grey),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.note,
                    color:
                        _selectedIndex == 1 ? Color(0xff321a70) : Colors.grey),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.person,
                    color:
                        _selectedIndex == 2 ? Color(0xff321a70) : Colors.grey),
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}
